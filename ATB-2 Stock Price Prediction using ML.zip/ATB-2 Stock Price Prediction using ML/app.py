import streamlit as st
import pandas as pd
import numpy as np
import joblib
from sklearn.preprocessing import StandardScaler

# Load the pre-trained model and scaler
model = joblib.load('stock_model.saw')
scaler = joblib.load('scaler.saw')

st.title("WIPRO Stock Price Prediction")
st.write("Enter stock details to predict the closing price.")

# User input fields
open_price = st.number_input("Open Price", min_value=0.0, format="%.2f")
high_price = st.number_input("High Price", min_value=0.0, format="%.2f")
low_price = st.number_input("Low Price", min_value=0.0, format="%.2f")
volume = st.number_input("Volume", min_value=0, format="%d")
ma_5 = st.number_input("5-day Moving Average", min_value=0.0, format="%.2f")

def predict_stock_price(open_price, high_price, low_price, volume, ma_5):
    new_data = np.array([[open_price, high_price, low_price, volume, ma_5]])
    new_data_scaled = scaler.transform(new_data)
    predicted_price = model.predict(new_data_scaled)
    return predicted_price[0]

if st.button("Predict Price"):
    if open_price and high_price and low_price and volume and ma_5:
        predicted_price = predict_stock_price(open_price, high_price, low_price, volume, ma_5)
        st.success(f'Predicted Closing Price: {predicted_price:.2f}')
    else:
        st.error("Please enter all required inputs.")
